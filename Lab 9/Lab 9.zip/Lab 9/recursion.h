#include <string>

using namespace std;

namespace CS262 {
	int gcd(const unsigned int x, const unsigned int y);
	double sumover(const unsigned int n);
	string reverse(string a, const unsigned int lowerBound, const unsigned int upBound);
}