#include "racingGame.cpp"

// Car Reader
LinkedList<car> carReader() {
	ifstream inFileCars( "cars.txt" );
		if( !inFileCars ) {
			cout << "Error opening file." << endl;
			system("PAUSE");
			exit(1);
	}
	
	string key, theName;
	LinkedList<car> cars;
	int value, theTopSpeed(0), theAcceleration, theHandling, i(0);
	
	while( getline(inFileCars,inString,lineDelimiter) ) {
		cout << inString << "$";
		if(i%5 == 0){
			theName = inString;
		} else {
			if(inString == "Top Speed") {
				inFileCars >> theTopSpeed;
				cout << theTopSpeed;
			} else if(inString == "Acceleration") {
				inFileCars >> theAcceleration;
				cout << theTopSpeed;
			} else if(inString == "Handling") {
				inFileCars >> theHandling;
				cout << theHandling;
			}
		}
		getline(inFileCars,inString);
		if(i%5 == 4) {
			car tempCar(theName, theTopSpeed, theAcceleration, theHandling);
			cars.insertAtTail(tempCar);
		}
		i++;
	}

	inFileCars.close();
	return cars;
}