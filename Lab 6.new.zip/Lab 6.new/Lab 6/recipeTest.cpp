#include <cstdlib>
#include "Recipe.h"
#include <iostream>

using namespace CS262;
using namespace std;

int main(){
	Recipe r;
	string name = r.get_Dish();

	return 0;
}

