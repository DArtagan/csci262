#include <cctype>
#include <iostream>
#include <cstdlib>
#include <limits>
#include <fstream>
#include <string>
#include <sstream>
#include <algorithm>
#include "LinkedList.h"
#include "car.h"
#include "carReader.cpp"
#include "trackReader.cpp"
using namespace std;
using namespace CS262;


int main() {
	// Initializing
	string inString;
	char carDelimiter = '=';
	char lineDelimiter = ':';
	LinkedList<car> cars;


	carReader();


	// Pause
	system("PAUSE");

	// Exit Program
	return 0;
}