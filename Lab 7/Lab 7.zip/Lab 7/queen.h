#pragma once

namespace CS262 {
	class queen {
		public:
			queen(int theRow = 1, int theCol = 1) : row(theRow), col(theCol) {}
			int row;
			int col;
	};
}

