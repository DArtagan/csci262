#pragma once
class node
{
public:
	node(void);
	~node(void);
};

