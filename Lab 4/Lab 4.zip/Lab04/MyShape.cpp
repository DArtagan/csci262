#include "MyShape.h"

using namespace std;
using System::Drawing::Color;
using System::Drawing::Point;
using System::Drawing::Graphics;
using namespace System::Drawing;
using namespace System::Drawing::Drawing2D;

namespace CS262 {

}